


 CLUSTAL 2.1 Multiple Sequence Alignments


Sequence format is Pearson
Sequence 1: AAX37051.1          148 aa
Sequence 2: AAX29557.1          148 aa
Sequence 3: NP_000509.1         148 aa
Sequence 4: XP_018891709.1      148 aa
Sequence 5: AAN84548.1          148 aa
Sequence 6: AAD19696.1          148 aa
Sequence 7: ACU56984.1          148 aa
Sequence 8: AAZ39780.1          148 aa
Sequence 9: AKI70610.1          148 aa
Sequence 10: AKI70611.1          148 aa

           AAX37051.1 
           AAX29557.1 
           NP_000509.1 
           XP_018891709.1 
           AAN84548.1 
           AAD19696.1 
           ACU56984.1 
           AAZ39780.1 
           AKI70610.1 
           AKI70611.1 
           AAX29557.1 
           NP_000509.1 
           XP_018891709.1 
           AAN84548.1 
           AAD19696.1 
           ACU56984.1 
           AAZ39780.1 
           AKI70610.1 
           AKI70611.1 
           NP_000509.1 
           XP_018891709.1 
           AAN84548.1 
           AAD19696.1 
           ACU56984.1 
           AAZ39780.1 
           AKI70610.1 
           AKI70611.1 
           XP_018891709.1 
           AAN84548.1 
           AAD19696.1 
           ACU56984.1 
           AAZ39780.1 
           AKI70610.1 
           AKI70611.1 
           AAN84548.1 
           AAD19696.1 
           ACU56984.1 
           AAZ39780.1 
           AKI70610.1 
           AKI70611.1 
           AAD19696.1 
           ACU56984.1 
           AAZ39780.1 
           AKI70610.1 
           AKI70611.1 
           ACU56984.1 
           AAZ39780.1 
           AKI70610.1 
           AKI70611.1 
           AAZ39780.1 
           AKI70610.1 
           AKI70611.1 
           AKI70610.1 
           AKI70611.1 
           AKI70611.1 
perc identity file created:   [/nfs/public/rw/es/projects/wp-jdispatcher/sources/prod-hl/jobs/mafft/interactive/20260306/1854/mafft-I20260306-185518-0746-5859264-p1m.sqr.pim]

Phylogenetic tree file created:   [/nfs/public/rw/es/projects/wp-jdispatcher/sources/prod-hl/jobs/mafft/interactive/20260306/1854/mafft-I20260306-185518-0746-5859264-p1m.sqr.ph]

