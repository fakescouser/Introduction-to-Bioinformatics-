


 CLUSTAL 2.1 Multiple Sequence Alignments


Sequence format is Pearson
Sequence 1: AAD19696.1          148 aa
Sequence 2: AAN84548.1          148 aa
Sequence 3: AAX29557.1          148 aa
Sequence 4: AAX37051.1          148 aa
Sequence 5: AAZ39780.1          148 aa
Sequence 6: ACU56984.1          148 aa
Sequence 7: AKI70610.1          148 aa
Sequence 8: AKI70611.1          148 aa
Sequence 9: NP_000509.1         148 aa
Sequence 10: XP_018891709.1      148 aa

           AAD19696.1 
           AAN84548.1 
           AAX29557.1 
           AAX37051.1 
           AAZ39780.1 
           ACU56984.1 
           AKI70610.1 
           AKI70611.1 
           NP_000509.1 
           XP_018891709.1 
           AAN84548.1 
           AAX29557.1 
           AAX37051.1 
           AAZ39780.1 
           ACU56984.1 
           AKI70610.1 
           AKI70611.1 
           NP_000509.1 
           XP_018891709.1 
           AAX29557.1 
           AAX37051.1 
           AAZ39780.1 
           ACU56984.1 
           AKI70610.1 
           AKI70611.1 
           NP_000509.1 
           XP_018891709.1 
           AAX37051.1 
           AAZ39780.1 
           ACU56984.1 
           AKI70610.1 
           AKI70611.1 
           NP_000509.1 
           XP_018891709.1 
           AAZ39780.1 
           ACU56984.1 
           AKI70610.1 
           AKI70611.1 
           NP_000509.1 
           XP_018891709.1 
           ACU56984.1 
           AKI70610.1 
           AKI70611.1 
           NP_000509.1 
           XP_018891709.1 
           AKI70610.1 
           AKI70611.1 
           NP_000509.1 
           XP_018891709.1 
           AKI70611.1 
           NP_000509.1 
           XP_018891709.1 
           NP_000509.1 
           XP_018891709.1 
           XP_018891709.1 
perc identity file created:   [/nfs/public/rw/es/projects/wp-jdispatcher/sources/prod-hx/jobs/tcoffee/interactive/20260306/1850/tcoffee-I20260306-185116-0427-181474-p2m.sqr.pim]

Phylogenetic tree file created:   [/nfs/public/rw/es/projects/wp-jdispatcher/sources/prod-hx/jobs/tcoffee/interactive/20260306/1850/tcoffee-I20260306-185116-0427-181474-p2m.sqr.ph]

