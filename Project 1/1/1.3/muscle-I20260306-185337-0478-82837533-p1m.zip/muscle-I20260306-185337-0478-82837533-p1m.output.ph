


 CLUSTAL 2.1 Multiple Sequence Alignments


Sequence format is Pearson
Sequence 1: AAN84548.1          148 aa
Sequence 2: XP_018891709.1      148 aa
Sequence 3: ACU56984.1          148 aa
Sequence 4: AAZ39780.1          148 aa
Sequence 5: AAD19696.1          148 aa
Sequence 6: AKI70610.1          148 aa
Sequence 7: AKI70611.1          148 aa
Sequence 8: AAX37051.1          148 aa
Sequence 9: AAX29557.1          148 aa
Sequence 10: NP_000509.1         148 aa

           AAN84548.1 
           XP_018891709.1 
           ACU56984.1 
           AAZ39780.1 
           AAD19696.1 
           AKI70610.1 
           AKI70611.1 
           AAX37051.1 
           AAX29557.1 
           NP_000509.1 
           XP_018891709.1 
           ACU56984.1 
           AAZ39780.1 
           AAD19696.1 
           AKI70610.1 
           AKI70611.1 
           AAX37051.1 
           AAX29557.1 
           NP_000509.1 
           ACU56984.1 
           AAZ39780.1 
           AAD19696.1 
           AKI70610.1 
           AKI70611.1 
           AAX37051.1 
           AAX29557.1 
           NP_000509.1 
           AAZ39780.1 
           AAD19696.1 
           AKI70610.1 
           AKI70611.1 
           AAX37051.1 
           AAX29557.1 
           NP_000509.1 
           AAD19696.1 
           AKI70610.1 
           AKI70611.1 
           AAX37051.1 
           AAX29557.1 
           NP_000509.1 
           AKI70610.1 
           AKI70611.1 
           AAX37051.1 
           AAX29557.1 
           NP_000509.1 
           AKI70611.1 
           AAX37051.1 
           AAX29557.1 
           NP_000509.1 
           AAX37051.1 
           AAX29557.1 
           NP_000509.1 
           AAX29557.1 
           NP_000509.1 
           NP_000509.1 
perc identity file created:   [/nfs/public/rw/es/projects/wp-jdispatcher/sources/prod-hl/jobs/muscle/interactive/20260306/1852/muscle-I20260306-185337-0478-82837533-p1m.sqr.pim]

Phylogenetic tree file created:   [/nfs/public/rw/es/projects/wp-jdispatcher/sources/prod-hl/jobs/muscle/interactive/20260306/1852/muscle-I20260306-185337-0478-82837533-p1m.sqr.ph]

